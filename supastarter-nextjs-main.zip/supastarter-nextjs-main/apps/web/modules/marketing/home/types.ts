import type { ReactNode } from "react";

export type FAQ = {
	question: ReactNode;
	answer: ReactNode;
};
