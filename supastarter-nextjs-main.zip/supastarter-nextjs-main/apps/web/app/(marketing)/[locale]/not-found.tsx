import { NotFound } from "@marketing/shared/components/NotFound";

export default async function NotFoundPage() {
	return <NotFound />;
}
