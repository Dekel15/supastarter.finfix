---
title: Terms and conditions
---

This is the placeholder page for your terms and conditions. Edit the `content/legal/terms.md` file to add your own content here.
