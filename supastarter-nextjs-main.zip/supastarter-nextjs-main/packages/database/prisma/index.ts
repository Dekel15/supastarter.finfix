export * from "./client";
export * from "./queries";
export * from "./zod";

declare global {
	namespace PrismaJson {}
}
